// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file CameraCommonInterfaceSkel.cpp 
 * @brief CameraCommonInterface server skeleton wrapper
 * @date Mon Sep  4 23:57:47 2017 
 *
 */

#include "CameraCommonInterfaceSkel.h"

#if defined ORB_IS_TAO
#  include "CameraCommonInterfaceC.cpp"
#  include "CameraCommonInterfaceS.cpp"
#elif defined ORB_IS_OMNIORB
#  include "CameraCommonInterfaceSK.cc"
#  include "CameraCommonInterfaceDynSK.cc"
#elif defined ORB_IS_MICO
#  include "CameraCommonInterface.cc"
#  include "CameraCommonInterface_skel.cc"
#elif defined ORB_IS_ORBIT2
#  include "CameraCommonInterface-cpp-stubs.cc"
#  include "CameraCommonInterface-cpp-skels.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "CameraCommonInterface-common.c"
#  include "CameraCommonInterface-stubs.c"
#  include "CameraCommonInterface-skels.c"
#  include "CameraCommonInterface-skelimpl.c"
#else
#  error "NO ORB defined"
#endif

// end of CameraCommonInterfaceSkel.cpp
