#!/bin/sh
omniidl -bpython -I"%RTM_ROOT%rtm\idl" -I"/usr/include/openrtm-1.1/rtm/idl" idl/CalibrationService.idl 
