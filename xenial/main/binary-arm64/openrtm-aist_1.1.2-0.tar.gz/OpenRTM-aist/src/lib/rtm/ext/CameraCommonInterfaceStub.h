// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file CameraCommonInterfaceStub.h 
 * @brief CameraCommonInterface client stub header wrapper code
 * @date Mon Sep  4 23:57:47 2017 
 *
 */

#ifndef _CAMERACOMMONINTERFACESTUB_H
#define _CAMERACOMMONINTERFACESTUB_H



#include <rtm/config_rtc.h>
#undef PACKAGE_BUGREPORT
#undef PACKAGE_NAME
#undef PACKAGE_STRING
#undef PACKAGE_TARNAME
#undef PACKAGE_VERSION

#if   defined ORB_IS_TAO
#  include "CameraCommonInterfaceC.h"
#elif defined ORB_IS_OMNIORB
#  if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
#    undef USE_stub_in_nt_dll
#  endif
#  include "CameraCommonInterface.hh"
#elif defined ORB_IS_MICO
#  include "CameraCommonInterface.h"
#elif defined ORB_IS_ORBIT2
#  include "CameraCommonInterface-cpp-stubs.h"
#elif defined ORB_IS_RTORB
#  include "CameraCommonInterface.h"
#else
#  error "NO ORB defined"
#endif

#endif // _CAMERACOMMONINTERFACESTUB_H
