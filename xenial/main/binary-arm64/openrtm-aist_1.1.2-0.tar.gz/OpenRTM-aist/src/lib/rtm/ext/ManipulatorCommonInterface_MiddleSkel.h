// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ManipulatorCommonInterface_MiddleSkel.h 
 * @brief ManipulatorCommonInterface_Middle server skeleton header wrapper code
 * @date Mon Sep  4 23:57:47 2017 
 *
 */

#ifndef _MANIPULATORCOMMONINTERFACE_MIDDLESKEL_H
#define _MANIPULATORCOMMONINTERFACE_MIDDLESKEL_H



#include <rtm/config_rtc.h>
#undef PACKAGE_BUGREPORT
#undef PACKAGE_NAME
#undef PACKAGE_STRING
#undef PACKAGE_TARNAME
#undef PACKAGE_VERSION

#if   defined ORB_IS_TAO
#  include "ManipulatorCommonInterface_MiddleC.h"
#  include "ManipulatorCommonInterface_MiddleS.h"
#elif defined ORB_IS_OMNIORB
#  if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
#    undef USE_stub_in_nt_dll
#  endif
#  include "ManipulatorCommonInterface_Middle.hh"
#elif defined ORB_IS_MICO
#  include "ManipulatorCommonInterface_Middle.h"
#elif defined ORB_IS_ORBIT2
#  include "/ManipulatorCommonInterface_Middle-cpp-stubs.h"
#  include "/ManipulatorCommonInterface_Middle-cpp-skels.h"
#elif defined ORB_IS_RTORB
#  include "ManipulatorCommonInterface_Middle.h"
#else
#  error "NO ORB defined"
#endif

#endif // _MANIPULATORCOMMONINTERFACE_MIDDLESKEL_H
