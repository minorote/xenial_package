#!/bin/sh

./HelloRTWorldComp 
