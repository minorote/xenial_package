// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ManipulatorCommonInterface_MiddleSkel.cpp 
 * @brief ManipulatorCommonInterface_Middle server skeleton wrapper
 * @date Thu May 26 10:45:54 2016 
 *
 */

#include "ManipulatorCommonInterface_MiddleSkel.h"

#if defined ORB_IS_TAO
#  include "ManipulatorCommonInterface_MiddleC.cpp"
#  include "ManipulatorCommonInterface_MiddleS.cpp"
#elif defined ORB_IS_OMNIORB
#  include "ManipulatorCommonInterface_MiddleSK.cc"
#  include "ManipulatorCommonInterface_MiddleDynSK.cc"
#elif defined ORB_IS_MICO
#  include "ManipulatorCommonInterface_Middle.cc"
#  include "ManipulatorCommonInterface_Middle_skel.cc"
#elif defined ORB_IS_ORBIT2
#  include "ManipulatorCommonInterface_Middle-cpp-stubs.cc"
#  include "ManipulatorCommonInterface_Middle-cpp-skels.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "ManipulatorCommonInterface_Middle-common.c"
#  include "ManipulatorCommonInterface_Middle-stubs.c"
#  include "ManipulatorCommonInterface_Middle-skels.c"
#  include "ManipulatorCommonInterface_Middle-skelimpl.c"
#else
#  error "NO ORB defined"
#endif

// end of ManipulatorCommonInterface_MiddleSkel.cpp
