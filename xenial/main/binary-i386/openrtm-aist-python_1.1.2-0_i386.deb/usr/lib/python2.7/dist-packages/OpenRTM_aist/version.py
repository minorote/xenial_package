#!/usr/bin/env python
# -*- coding: euc-jp -*-

openrtm_name    = "OpenRTM-aist-1.1.0"
openrtm_version = "1.1.0"
corba_name      = "omniORB"
